# SPDX-FileCopyrightText: 2017 yuzu Emulator Project
# SPDX-FileCopyrightText: 2025 citron Emulator Project
# SPDX-License-Identifier: GPL-2.0-or-later

# This function downloads a binary library package from our external repo.
# Params:
#   remote_path: path to the file to download, relative to the remote repository root
#   prefix_var: name of a variable which will be set with the path to the extracted contents
set(CURRENT_MODULE_DIR ${CMAKE_CURRENT_LIST_DIR})
function(download_bundled_external remote_path lib_name prefix_var)

set(package_repo "no_platform")
set(package_extension "no_platform")
# Use yuzu-mirror GitHub repositories for external binaries (more reliable than self-hosted)
set(package_base_url "https://github.com/yuzu-mirror/")
if (WIN32)
    # https://github.com/yuzu-mirror/ext-windows-bin
    set(package_repo "ext-windows-bin/raw/master/")
    set(package_extension ".7z")
elseif (${CMAKE_SYSTEM_NAME} STREQUAL "Linux")
    # https://github.com/yuzu-mirror/ext-linux-bin
    set(package_repo "ext-linux-bin/raw/main/")
    set(package_extension ".tar.xz")
elseif (ANDROID)
    # https://github.com/yuzu-mirror/ext-android-bin
    # Files are named with architecture suffix (e.g., ffmpeg-android-v5.1.LTS-aarch64.tar.xz)
    set(package_repo "ext-android-bin/raw/main/")
    set(package_extension ".tar.xz")
else()
    message(FATAL_ERROR "No package available for this platform")
endif()
set(package_url "${package_base_url}${package_repo}")

set(prefix "${CMAKE_BINARY_DIR}/externals/${lib_name}")
if (NOT EXISTS "${prefix}")
    set(download_url "${package_url}${remote_path}${lib_name}${package_extension}")
    set(download_path "${CMAKE_BINARY_DIR}/externals/${lib_name}${package_extension}")
    message(STATUS "Downloading binaries for ${lib_name} from ${download_url}...")
    file(DOWNLOAD
        ${download_url}
        ${download_path}
        SHOW_PROGRESS
        STATUS download_status)
    list(GET download_status 0 status_code)
    list(GET download_status 1 status_string)
    if (NOT status_code EQUAL 0)
        message(FATAL_ERROR "Failed to download ${lib_name}: ${status_string} (${status_code})\nURL: ${download_url}")
    endif()
    # Verify the downloaded file is not empty or an error page
    file(SIZE ${download_path} download_size)
    if (download_size LESS 1000)
        file(READ ${download_path} download_content LIMIT 500)
        message(FATAL_ERROR "Downloaded file for ${lib_name} appears invalid (size: ${download_size} bytes).\nURL: ${download_url}\nContent preview: ${download_content}")
    endif()
    execute_process(
        COMMAND ${CMAKE_COMMAND} -E tar xf ${download_path}
        WORKING_DIRECTORY "${CMAKE_BINARY_DIR}/externals"
        RESULT_VARIABLE extract_result)
    if (NOT extract_result EQUAL 0)
        message(FATAL_ERROR "Failed to extract ${lib_name} archive: ${extract_result}")
    endif()
endif()
message(STATUS "Using bundled binaries at ${prefix}")
set(${prefix_var} "${prefix}" PARENT_SCOPE)
endfunction()

function(download_moltenvk_external platform version)
    set(MOLTENVK_DIR "${CMAKE_BINARY_DIR}/externals/MoltenVK-${version}")
    set(MOLTENVK_TAR "${CMAKE_BINARY_DIR}/externals/MoltenVK-${version}.tar")
    string(TOLOWER "${platform}" MOLTENVK_ASSET_PLATFORM)
    if (NOT EXISTS ${MOLTENVK_DIR})
        if (NOT EXISTS ${MOLTENVK_TAR})
            file(DOWNLOAD https://github.com/KhronosGroup/MoltenVK/releases/download/${version}/MoltenVK-${MOLTENVK_ASSET_PLATFORM}.tar
                ${MOLTENVK_TAR} SHOW_PROGRESS STATUS download_status)
            list(GET download_status 0 download_code)
            if (NOT download_code EQUAL 0)
                file(REMOVE ${MOLTENVK_TAR})
                message(FATAL_ERROR "Failed to download MoltenVK: ${download_status}")
            endif()
        endif()

        set(MOLTENVK_STAGING_DIR "${MOLTENVK_DIR}.tmp")
        file(REMOVE_RECURSE ${MOLTENVK_STAGING_DIR})
        file(MAKE_DIRECTORY ${MOLTENVK_STAGING_DIR})
        execute_process(COMMAND ${CMAKE_COMMAND} -E tar xf "${MOLTENVK_TAR}"
            WORKING_DIRECTORY ${MOLTENVK_STAGING_DIR}
            RESULT_VARIABLE extract_result)
        if (NOT extract_result EQUAL 0)
            file(REMOVE_RECURSE ${MOLTENVK_STAGING_DIR})
            file(REMOVE ${MOLTENVK_TAR})
            message(FATAL_ERROR "Failed to extract MoltenVK: ${extract_result}")
        endif()
        file(RENAME ${MOLTENVK_STAGING_DIR} ${MOLTENVK_DIR})
    endif()

    set(MOLTENVK_LIBRARY_DIR "${MOLTENVK_DIR}/MoltenVK/MoltenVK/dylib/${platform}" PARENT_SCOPE)
endfunction()

# Determine installation parameters for OS, architecture, and compiler
# Qt 6.8+ uses msvc2022; Qt 6.7 and older use msvc2019
function(determine_qt_parameters target host_out type_out arch_out arch_path_out host_type_out host_arch_out host_arch_path_out)
    # Determine the HOST platform (where aqt will run)
    if (CMAKE_HOST_WIN32)
        set(host "windows")
    elseif (CMAKE_HOST_APPLE)
        set(host "mac")
    else()
        set(host "linux")
    endif()

    # Determine the TARGET architecture parameters
    if (CMAKE_SYSTEM_NAME STREQUAL "Windows")
        set(type "desktop")

        if (NOT tool)
            # Check if target is Qt 6.8+ (use msvc2022) or 6.7.x and older (use msvc2019)
            if (target MATCHES "^6\\.([89]|[0-9][0-9])\\.|^[7-9]\\.")
                set(msvc_arch "msvc2022")
            else()
                set(msvc_arch "msvc2019")
            endif()

            if (CMAKE_CXX_COMPILER_ID STREQUAL "Clang")
                set(arch "win64_llvm_mingw")
                set(arch_path "llvm-mingw_64")
            elseif (MINGW)
                set(arch "win64_mingw")
                set(arch_path "mingw_64")
            elseif (MSVC)
                if ("arm64" IN_LIST ARCHITECTURE)
                    set(arch_path "${msvc_arch}_arm64")
                elseif ("x86_64" IN_LIST ARCHITECTURE)
                    set(arch_path "${msvc_arch}_64")
                else()
                    message(FATAL_ERROR "Unsupported bundled Qt architecture. Enable USE_SYSTEM_QT and provide your own.")
                endif()
                set(arch "win64_${arch_path}")
            else()
                message(FATAL_ERROR "Unsupported bundled Qt toolchain. Enable USE_SYSTEM_QT and provide your own.")
            endif()

            # For host tools (e.g. moc/rcc), we usually want the native host version of the same Qt version
            if (CMAKE_HOST_WIN32)
                if (MSVC)
                    if (CMAKE_HOST_SYSTEM_PROCESSOR STREQUAL "AMD64")
                        set(host_arch_path "${msvc_arch}_64")
                    elseif (CMAKE_HOST_SYSTEM_PROCESSOR STREQUAL "ARM64")
                        set(host_arch_path "${msvc_arch}_64")
                    endif()
                    set(host_arch "win64_${host_arch_path}")
                endif()
            elseif (CMAKE_HOST_APPLE)
                set(host_arch "clang_64")
                set(host_arch_path "macos")
            else() # Linux
                set(host_arch "gcc_64")
                set(host_arch_path "linux")
            endif()
        endif()
    elseif (APPLE)
        set(type "desktop")
        set(arch "clang_64")
        set(arch_path "macos")
    else() # Linux target
        set(type "desktop")
        set(arch "gcc_64")
        set(arch_path "linux")
    endif()

    set(${host_out} "${host}" PARENT_SCOPE)
    set(${type_out} "${type}" PARENT_SCOPE)
    set(${arch_out} "${arch}" PARENT_SCOPE)
    set(${arch_path_out} "${arch_path}" PARENT_SCOPE)

    if (DEFINED host_type)
        set(${host_type_out} "${host_type}" PARENT_SCOPE)
    else()
        set(${host_type_out} "${type}" PARENT_SCOPE)
    endif()

    if (DEFINED host_arch)
        set(${host_arch_out} "${host_arch}" PARENT_SCOPE)
    else()
        set(${host_arch_out} "${arch}" PARENT_SCOPE)
    endif()

    if (DEFINED host_arch_path)
        set(${host_arch_path_out} "${host_arch_path}" PARENT_SCOPE)
    else()
        set(${host_arch_path_out} "${arch_path}" PARENT_SCOPE)
    endif()
endfunction()

# Download Qt binaries for a specific configuration.
function(download_qt_configuration prefix_out target host type arch arch_path base_path)
    if (target MATCHES "tools_.*")
        set(tool ON)
    else()
        set(tool OFF)
    endif()

    set(install_args -c "${CURRENT_MODULE_DIR}/aqt_config.ini")
    if (tool)
        set(prefix "${base_path}/Tools")
        set(install_args ${install_args} install-tool --outputdir ${base_path} ${host} desktop ${target})
    else()
        set(prefix "${base_path}/${target}/${arch_path}")
        # Use --autodesktop for Qt 6.8+ (package structure changed); otherwise explicit archives
        if (target MATCHES "^6\\.([89]|[0-9][0-9])\\.|^[7-9]\\.")
            set(install_args ${install_args} install-qt --outputdir ${base_path} ${host} ${type} ${target} ${arch}
                    --autodesktop -m qtmultimedia)
        else()
            set(install_args ${install_args} install-qt --outputdir ${base_path} ${host} ${type} ${target} ${arch}
                    -m qtmultimedia --archives qttranslations qttools qtsvg qtbase)
        endif()
    endif()

    if (NOT EXISTS "${prefix}")
        message(STATUS "Downloading Qt binaries for ${target}:${host}:${type}:${arch}:${arch_path}")
        set(AQT_PREBUILD_BASE_URL "https://github.com/miurahr/aqtinstall/releases/download/v3.3.0")
        if (WIN32)
            set(aqt_path "${base_path}/aqt.exe")
            if (NOT EXISTS "${aqt_path}")
                file(DOWNLOAD
                        ${AQT_PREBUILD_BASE_URL}/aqt.exe
                        ${aqt_path} SHOW_PROGRESS)
            endif()
            execute_process(COMMAND ${aqt_path} ${install_args}
                    WORKING_DIRECTORY ${base_path}
                    RESULT_VARIABLE aqt_result)
            if (NOT aqt_result EQUAL 0)
                message(WARNING "aqt install failed, trying without multimedia module")
                if (target MATCHES "^6\\.([89]|[0-9][0-9])\\.|^[7-9]\\.")
                    set(install_args -c "${CURRENT_MODULE_DIR}/aqt_config.ini" install-qt --outputdir ${base_path} ${host} ${type} ${target} ${arch} --autodesktop)
                else()
                    set(install_args -c "${CURRENT_MODULE_DIR}/aqt_config.ini" install-qt --outputdir ${base_path} ${host} ${type} ${target} ${arch} --archives qttranslations qttools qtsvg qtbase)
                endif()
                execute_process(COMMAND ${aqt_path} ${install_args}
                        WORKING_DIRECTORY ${base_path})
            endif()
        elseif (APPLE)
            set(aqt_path "${base_path}/aqt-macos")
            if (NOT EXISTS "${aqt_path}")
                file(DOWNLOAD
                        ${AQT_PREBUILD_BASE_URL}/aqt-macos
                        ${aqt_path} SHOW_PROGRESS)
            endif()
            execute_process(COMMAND chmod +x ${aqt_path})
            execute_process(COMMAND ${aqt_path} ${install_args}
                    WORKING_DIRECTORY ${base_path})
        else()
            set(aqt_install_path "${base_path}/aqt")
            file(MAKE_DIRECTORY "${aqt_install_path}")

            execute_process(COMMAND python3 -m pip install --target=${aqt_install_path} aqtinstall
                    WORKING_DIRECTORY ${base_path})
            execute_process(COMMAND ${CMAKE_COMMAND} -E env PYTHONPATH=${aqt_install_path} python3 -m aqt ${install_args}
                    WORKING_DIRECTORY ${base_path})
        endif()

        message(STATUS "Downloaded Qt binaries for ${target}:${host}:${type}:${arch}:${arch_path} to ${prefix}")
    endif()

    set(${prefix_out} "${prefix}" PARENT_SCOPE)
endfunction()

# This function downloads Qt using aqt.
# The path of the downloaded content will be added to the CMAKE_PREFIX_PATH.
# QT_TARGET_PATH is set to the Qt for the compile target platform.
# QT_HOST_PATH is set to a host-compatible Qt, for running tools.
# Params:
#   target: Qt dependency to install. Specify a version number to download Qt, or "tools_(name)" for a specific build tool.
function(download_qt target)
    determine_qt_parameters("${target}" host type arch arch_path host_type host_arch host_arch_path)

    get_external_prefix(qt base_path)
    file(MAKE_DIRECTORY "${base_path}")

    download_qt_configuration(prefix "${target}" "${host}" "${type}" "${arch}" "${arch_path}" "${base_path}")
    if (DEFINED host_arch_path AND NOT "${host_arch_path}" STREQUAL "${arch_path}")
        download_qt_configuration(host_prefix "${target}" "${host}" "${host_type}" "${host_arch}" "${host_arch_path}" "${base_path}")
    else()
        set(host_prefix "${prefix}")
    endif()

    set(QT_TARGET_PATH "${prefix}" CACHE STRING "")
    set(QT_HOST_PATH "${host_prefix}" CACHE STRING "")

    list(APPEND CMAKE_PREFIX_PATH "${prefix}")
    set(CMAKE_PREFIX_PATH ${CMAKE_PREFIX_PATH} PARENT_SCOPE)
endfunction()

function(download_moltenvk)
set(MOLTENVK_PLATFORM "macOS")

set(MOLTENVK_DIR "${CMAKE_BINARY_DIR}/externals/MoltenVK")
set(MOLTENVK_TAR "${CMAKE_BINARY_DIR}/externals/MoltenVK.tar")
if (NOT EXISTS ${MOLTENVK_DIR})
if (NOT EXISTS ${MOLTENVK_TAR})
    file(DOWNLOAD https://github.com/KhronosGroup/MoltenVK/releases/download/v1.2.10-rc2/MoltenVK-all.tar
    ${MOLTENVK_TAR} SHOW_PROGRESS)
endif()

execute_process(COMMAND ${CMAKE_COMMAND} -E tar xf "${MOLTENVK_TAR}"
    WORKING_DIRECTORY "${CMAKE_BINARY_DIR}/externals")
endif()

# Add the MoltenVK library path to the prefix so find_library can locate it.
list(APPEND CMAKE_PREFIX_PATH "${MOLTENVK_DIR}/MoltenVK/dylib/${MOLTENVK_PLATFORM}")
set(CMAKE_PREFIX_PATH ${CMAKE_PREFIX_PATH} PARENT_SCOPE)
endfunction()

function(get_external_prefix lib_name prefix_var)
    set(${prefix_var} "${CMAKE_BINARY_DIR}/externals/${lib_name}" PARENT_SCOPE)
endfunction()
